/**
 * Package camix.service du programme Camix.
 * 
 * <p>Ce package fournit les classes du service chat de Camix 
 * ainsi que la suite de tests associée.</p>
 * 
 * @version 0.3.1
 * @author Matthias Brun
 */
package camix.service;

