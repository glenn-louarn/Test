package camix;


public class CamixTestSuite {
}
