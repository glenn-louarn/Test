package camix.communication;

public class CamixCommunicationTestSuite {
}
