package camix.service;

import org.easymock.*;
import org.junit.*;

import java.lang.reflect.Field;
import java.util.Hashtable;

public class CanalChatTestEx1EasyMock {

    @Mock
    private ClientChat clientMock;

    @TestSubject
    private CanalChat canalChat;

    @Before
    public void setup() throws Exception{
        this.clientMock = EasyMock.createMock(ClientChat.class);
        this.canalChat = EasyMock.partialMockBuilder(CanalChat.class).addMockedMethod("estPresent").withConstructor("test").createMock();
    }
    @Test
    public void testAjouteClient_non_present() throws Exception {
        final String message = "Ajout client :";
        final String id = "1";

        EasyMock.expect(this.canalChat.estPresent(this.clientMock)).andReturn(true);
        EasyMock.expect(this.clientMock.donneId()).andReturn(id).times(1);

        EasyMock.replay(canalChat);
        EasyMock.replay(clientMock);
        // Pour l'accès au field caché (privé)
        String attributConcerne = "clients";
        Field attribut;

        attribut = CanalChat.class.getDeclaredField(attributConcerne);
        attribut.setAccessible(true);
        Hashtable<String, ClientChat> table = (Hashtable<String, ClientChat>) attribut.get(this.canalChat);
        table.put(clientMock.donneId(), clientMock);
        Assert.assertEquals(1, table.size());
        Assert.assertTrue(table.contains(this.clientMock));
        EasyMock.verify(this.clientMock);
    }

    @Test
    public void testAjouteClient_non_present_2_1() throws Exception {
        final String message = "Ajout client :";
        final String id = "3";

        EasyMock.expect(this.clientMock.donneId()).andReturn(id).times(1);

        EasyMock.replay(clientMock);
        //Pour l'accès au field caché (privé)
        String attributConcerne = "clients";
        Field attribut;

        attribut = CanalChat.class.getDeclaredField(attributConcerne);
        attribut.setAccessible(true);

        Hashtable<String, ClientChat> table = (Hashtable<String, ClientChat>) attribut.get(this.canalChat);
        table.put(clientMock.donneId(), clientMock);

        Assert.assertEquals(1, table.size());
        Assert.assertTrue(table.contains(this.clientMock));

        EasyMock.verify(this.clientMock);
    }
//    @Test
//    public void ajouteClient() {
//        final String id = "id client";
//
//        final int repetitions = 5;
//
//        EasyMock.expect(
//                this.clientMock.donneId()
//        ).andReturn(
//               id
//        );
//
//        EasyMock.expectLastCall().times(repetitions);
//
//        EasyMock.replay(this.clientMock);
//
//        this.canalChat.ajouteClient(this.clientMock);
//
//        Assert.assertEquals("Nombre de clients incompatible", 1, (int) canalChat.donneNombreClients());
//        Assert.assertTrue("Le client n'est pas dans le canal", canalChat.estPresent(this.clientMock));
//
//        this.canalChat.ajouteClient(this.clientMock);
//
//        Assert.assertEquals("Nombre de clients incompatible", 1, (int) canalChat.donneNombreClients());
//        Assert.assertTrue("Le client n'est pas dans le canal", canalChat.estPresent(this.clientMock));
//
//        EasyMock.verify(this.clientMock);
//    }
//
//    @Test
//    public void ajouteClientSideEffect() {
//        final String id = "id client";
//
//        final int repetitions = 5;
//
//        EasyMock.expect(
//                this.clientMock.donneId()
//        ).andReturn(
//                id
//        );
//
//        EasyMock.expectLastCall().times(repetitions);
//
//        EasyMock.replay(this.clientMock);
//
//        this.canalChat.ajouteClient(this.clientMock);
//
//        Assert.assertEquals("Nombre de clients incompatible", 1, (int) canalChat.donneNombreClients());
//        Assert.assertTrue("Le client n'est pas dans le canal", canalChat.estPresent(this.clientMock));
//
//        this.canalChat.ajouteClient(this.clientMock);
//
//        Assert.assertEquals("Nombre de clients incompatible", 1, (int) canalChat.donneNombreClients());
//        Assert.assertTrue("Le client n'est pas dans le canal", canalChat.estPresent(this.clientMock));
//
//        EasyMock.verify(this.clientMock);
//    }
 }