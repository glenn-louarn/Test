package camix.service;

public class CamixServiceTestSuite {
}
