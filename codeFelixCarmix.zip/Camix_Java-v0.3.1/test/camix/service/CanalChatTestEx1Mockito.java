package camix.service;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;
import java.util.Hashtable;

import static org.mockito.Mockito.*;

public class CanalChatTestEx1Mockito {
//    private ClientChat clientChatMock;
    private CanalChat canalChat2;
    private ClientChat clientChatMock2;

    @Before
    public void setUp() throws Exception {
        clientChatMock2 = Mockito.mock(ClientChat.class);
        canalChat2 = new CanalChat("uncanal");
//        this.canalChat = EasyMock.partialMockBuilder(CanalChat.class).addMockedMethod("estPresent").withConstructor("test").createMock();
//        this.clientChatMock = EasyMock.createMock(ClientChat.class);
    }

    @Test
    public void testAjouteClientPresentMK(){
        String id ="unId";
        when(clientChatMock2.donneId()).thenReturn(id);
        canalChat2.ajouteClient(clientChatMock2);
        Assert.assertEquals(
                "produit non conforme",
                1,
                (int) canalChat2.donneNombreClients()
        );
        Assert.assertTrue(
                "produit non conforme",
                canalChat2.estPresent(clientChatMock2)
        );
        CanalChat toBeMocked = new CanalChat("name");
        CanalChat spyToBeMocked = Mockito.spy(toBeMocked);

        Mockito.doReturn(true).when(spyToBeMocked).estPresent(clientChatMock2);

    }



//    @Test
//    public void testAjouteClientNonPresent_1_1() {
//        final CanalChat canalChat = new CanalChat("test");
//
//        final String id = "id client ";
//
//        final int repetition = 3;
//
//        EasyMock.expect(this.clientChatMock.donneId()).andReturn(id).times(repetition);
//
//        EasyMock.replay(this.clientChatMock);
//
//        canalChat.ajouteClient(clientChatMock);
//
//        Assert.assertEquals(
//                "produit non conforme",
//                1,
//                (int) canalChat.donneNombreClients()
//        );
//        Assert.assertTrue(
//                "produit non conforme",
//                canalChat.estPresent(clientChatMock)
//        );
//
//        EasyMock.verify((this.clientChatMock));
//
//    }
//
//    @Test
//    public void testAjouterClient_Present_1_1() {
//        CanalChat canalChat = new CanalChat("un canal");
//
//        EasyMock.expect(
//                this.clientChatMock.donneId()
//        ).andReturn(
//                "ID1"
//        ).times(5);
//        EasyMock.replay(this.clientChatMock);
//        canalChat.ajouteClient(this.clientChatMock);
//        Assert.assertEquals((int) canalChat.donneNombreClients(), 1);
//        Assert.assertEquals((boolean) canalChat.estPresent(this.clientChatMock), true);
//        canalChat.ajouteClient(this.clientChatMock);
//        Assert.assertEquals((int) canalChat.donneNombreClients(), 1);
//        Assert.assertEquals((boolean) canalChat.estPresent(this.clientChatMock), true);
//        EasyMock.verify(this.clientChatMock);
//    }
}
