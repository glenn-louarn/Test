/**
 * Package felix du programme Felix.
 * 
 * <p>Ce package fournit la classe principale (main) du programme 
 * ainsi que la suite de tests associée.</p>
 * 
 * @version 0.3.1
 * @author Matthias Brun
 */
package felix;
